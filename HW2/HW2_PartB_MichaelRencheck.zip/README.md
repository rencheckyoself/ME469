MICHAEL RENCHECK

HOMEWORK 2 Part A

Instructions:
1) Place all python scripts in the same directory as the dataset.

2) Run run_me.py file making sure the terminal is set to the directory containing the script and data.
      -The file is configured to run part a and part b the data used in Test 1 from the report.
      - Run Time is ~10min.
      - The general rule of thumb is 1 min of runtime for every 100 testing points

      -The file displays part a, questions 2 graphs and part b graphs  

3) The included learning_dataset.csv file is the input data for my algorithm.

4) The two Test folders contain all the graphs used in part b

5) Execute the data_creation.py file if you want to view the graphs for part a, question 1.
