MICHAEL RENCHECK

HOMEWORK 1 Part B

Instructions:
1) Place all python scripts in the same directory as the dataset.

2) Run run_me.py file making sure the terminal is set to the directory containing the script and data.
      -Run time is about 1 min (at least in my experience)
