MICHAEL RENCHECK

HOMEWORK 2 Part A

Instructions:
1) Place all python scripts in the same directory as the dataset.

2) Run run_me.py file making sure the terminal is set to the directory containing the script and data.
      -Run time is a few seconds (at least in my experience)

      -The file displays a graph of the LWLR applied to a noisy sine wave, the training set and test set are randomly generated each run.  

3) The included learned_data.csv file is the input data for my algorithm.
    The data has been normalized to account for variable time differences between commands.
    The first two columns are v, w. These are my inputs.
    The second three columns are the resulting change in x, y, and theta. These are my expected outputs
