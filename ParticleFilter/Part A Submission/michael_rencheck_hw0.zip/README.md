MICHAEL RENCHECK

HOMEWORK 0 Part A

Instructions:
1) Place all python scripts in the same directory as the dataset.

2) The pythons scripts depend on numpy and matplotlib libraries for data import
   and results printing.

3) Run run_me.py file making sure the terminal is set to the directory containing the script and data to view the results for each question.
      -Run time is less than 10s (at least in my experience)
